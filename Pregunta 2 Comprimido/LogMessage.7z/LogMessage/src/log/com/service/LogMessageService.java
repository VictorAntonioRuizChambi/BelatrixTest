package log.com.service;

public interface LogMessageService {
	public void logMessage(String messageText, String ouputType) throws Exception;
}
