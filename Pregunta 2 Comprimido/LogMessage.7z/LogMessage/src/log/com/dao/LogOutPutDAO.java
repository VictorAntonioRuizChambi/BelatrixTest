package log.com.dao;

public interface LogOutPutDAO {
	public int writeMessage(String message) throws Exception;
}
