package log.com.utilities;

public class MessageException {
	public static final String TEXT_MESSAGE_MUST_BE_SPECIFIED=  "TextMessage must be specified";
	public static final String OUTPUT_TYPE_MUST_BE_SPECIFIED= "OutPut Type must be specified";
}
